# helloworld

AstrBot 插件模板

A template plugin for AstrBot plugin feature

# 支持

[帮助文档](https://astrbot.app)
